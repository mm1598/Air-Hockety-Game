//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import static java.lang.System.*; 

public class TriangleThreeRunner
{
	public static void main( String args[] )
   {
		TriangleThree test = new TriangleThree();
		out.println( test.go( 3, "A" ));
	}
}