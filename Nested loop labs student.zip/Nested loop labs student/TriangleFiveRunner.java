//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleFiveRunner
{
   public static void main(String args[])
   {
		TriangleFive test = new TriangleFive();
		System.out.println( test.go( 4, 'C' ) );
	}
}