//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleThree
{
	public static String go( int size, String let )
	{
		String output="";
		for(int i=0; i<size; i++){
			for(int j=size; j>=i;j--){
				output+=" ";
			}
				for(int k=0; k<=i; k++){
					output+=let;
				}
				output+="\n";
			}
			return output;
	}
}