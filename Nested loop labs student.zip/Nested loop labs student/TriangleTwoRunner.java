//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleTwoRunner
{
	public static void main( String args[] )
   {
		TriangleTwo test = new TriangleTwo();
		System.out.println( test.go( 3,"A" ) );
	}
}