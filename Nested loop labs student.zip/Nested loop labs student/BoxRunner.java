//(c) A+ Computer Science
//www.apluscompsci.com
//Name - 

public class BoxRunner
{
   public static void main( String args[] )
   {
		Box test = new Box();
		System.out.println( test.go( 3 ) );
	}
}