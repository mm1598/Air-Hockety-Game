//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleFourRunner
{
   public static void main( String args[] )
   {
		TriangleFour test = new TriangleFour();
		System.out.println( test.go( 3,"R" ) );
	}
}