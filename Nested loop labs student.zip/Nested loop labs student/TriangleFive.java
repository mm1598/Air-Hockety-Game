//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleFive
{
	public static String go( int amount, char letter )
	{
		String output="";
		String alphabet[A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z];
		for(int i=1; i<=amount; i++){
			for(int j=amount; j>=i; j--)
		}
		return output;
	}
}