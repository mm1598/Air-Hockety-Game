//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import static java.lang.System.*; 

public class BoxWordRunner
{
   public static void main( String args[] )
   {
		BoxWord test = new BoxWord();
		out.println( test.go( "SQUARE" ) );
	}
}