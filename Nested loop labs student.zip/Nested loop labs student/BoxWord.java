//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class BoxWord
{
	public static String go( String word )
	{
		String output="";
		int a=1;
		int b=word.length()-2;
		output+=word+"\n";
		for (int i=0; i<word.length()-2; i++){
			output+=word.charAt(a);
			for(int x=0; x<word.length()-2; x++){
				output+=" ";
			}
			output+=word.charAt(b);
			a++;
			b--;
			output+="\n";

		}
		if(word.length()>1){
			for(int i=word.length()-1; i>=0; i--){
				output+=word.charAt(i);
			}
		}
		return output +"\n";
	}
}