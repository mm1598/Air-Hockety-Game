//(c) A+ Computer Science
//www.apluscompsci.com
//Name - 

public class TriangleTwo
{
	public static String go( int size, String let )
	{
		String output="";
		for(int x=1; x<=size; x++){
			for(int i=size; i>=x; i--){
				output+=let;
			}
			output+="\n";
		}
		return output;
	}
}