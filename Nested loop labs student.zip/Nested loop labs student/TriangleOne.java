//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class TriangleOne
{
   //this lab is setup with a single static method
   //there are no instance variables or additional methods / constructors

	public static String go( String let, int size)
	{
		String output="";
		for(int x=0; x<=size;x++){
			for(int a=1; a<=x;a++){
				output+=let;
			}
		output+="\n";
				
		}
		return output;
	}
}