//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

public class NumberSorter
{
	//instance variables and other methods not shown

	private static int getNumDigits(int number)
	{
		int count = 0;
		int x=10;
		while(number%x!=0){
			count++;
			x*=10;
		}
		return count;
	}

	public static int[] getSortedDigitArray(int number)
	{
		int[] sorted;
		for(int i=0; i<; i++){
		sorted[i]=((number/10) + (number%10));
		}
		return sorted;
	}
}