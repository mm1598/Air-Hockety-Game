//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import java.util.Arrays;

public class WordSort
{
	private String[] wordRay;

	public WordSort(String line)
	{
	   wordRay = line.split(" ");
	}

	public void setList(String line)
	{
		wordRay = line.split(" ");
	}

	public void sort()
	{
		for(int i=0; i<wordRay.length-1; i++){
			int min=i;
			for(int x=i+1; x<wordRay.length; x++){
				if(wordRay[x].compareTo(wordRay[min])<0){
					min=x;
				}
			}
			if(min!=i){
				String temp=wordRay[i];
				wordRay[i]=wordRay[min];
				wordRay[min]=(temp);
			}
		}
		
	}

	public String toString( )
	{
		String output="";
		for(int i=0; i<wordRay.length;i++){
			output+="WORD"+i+": "+wordRay[i]+" ";
			
		}
		return output+"\n\n";
	}
}