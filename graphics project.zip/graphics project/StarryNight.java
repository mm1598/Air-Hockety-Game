// kets w,s,up arrow, and down arrow, and c do something//
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JFrame;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.*;
import javax.sound.sampled.*;
import java.awt.Toolkit;
import java.net.*;

public class StarryNight extends JFrame {
    private static final int FRAME_WIDTH = 800;
    private static final int FRAME_HEIGHT = 600;
    private static final int STAR_COUNT = 50;
    private static final int STAR_SIZE = 3;
    private static final int CIRCLE_RADIUS = 50;
    private static final int SPACESHIP_WIDTH = 120;
    private static final int SPACESHIP_HEIGHT = 60;
    private static final int SPACESHIP_SPEED = 5;

    private int starSpeed = 1;
    private int mouseX;
    private int mouseY;
    private Color circleColor = Color.BLUE;
    private int spaceship1Y = FRAME_HEIGHT / 2;
    private int spaceship2X = FRAME_WIDTH / 2 - SPACESHIP_WIDTH / 2;

    private Timer timer;
    private Random random;
    private List<Circle> circles;
    private BufferedImage backgroundImage;

    public StarryNight() {
        setTitle("Starry Night");
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        try {
            backgroundImage = ImageIO.read(new File("background.jpeg"));
            backgroundImage = scaleImage(backgroundImage, FRAME_WIDTH, FRAME_HEIGHT);
        } catch (IOException e) {
            e.printStackTrace();
        }

        JPanel panel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                draw(g);
            }
        };
        panel.setBackground(Color.BLACK);
        add(panel);

        circles = new ArrayList<>();

        addMouseMotionListener(new MouseAdapter() {
            public void mouseMoved(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
                repaint();
            }
        });

        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1) { // Left mouse button
                    circleColor = getRandomColor();
                    repaint();
                }
            }
        });

        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_W) {
                    starSpeed++;
                } else if (e.getKeyCode() == KeyEvent.VK_S) {
                    starSpeed--;
                    if (starSpeed < 1) {
                        starSpeed = 1;
                    }
                } else if (e.getKeyCode() == KeyEvent.VK_C) {
                    int x = random.nextInt(FRAME_WIDTH);
                    int y = random.nextInt(FRAME_HEIGHT);
                    circles.add(new Circle(x, y, circleColor));
                    repaint();
                } else if (e.getKeyCode() == KeyEvent.VK_UP) {
                    spaceship1Y -= SPACESHIP_SPEED;
                    if (spaceship1Y < 0) {
                        spaceship1Y = 0;
                    }
                    repaint();
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    spaceship1Y += SPACESHIP_SPEED;
                    if (spaceship1Y + SPACESHIP_HEIGHT > FRAME_HEIGHT) {
                        spaceship1Y = FRAME_HEIGHT - SPACESHIP_HEIGHT;
                    }
                    repaint();
                } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    spaceship2X -= SPACESHIP_SPEED;
                    if (spaceship2X < 0) {
                        spaceship2X = 0;
                    }
                    repaint();
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    spaceship2X += SPACESHIP_SPEED;
                    if (spaceship2X + SPACESHIP_WIDTH > FRAME_WIDTH) {
                        spaceship2X = FRAME_WIDTH - SPACESHIP_WIDTH;
                    }
                    repaint();
                }
            }
        });

        random = new Random();
        timer = new Timer(10, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                moveStars();
                moveCircles();
                panel.repaint();
            }
        });

        timer.start();
    }

    private void moveStars() {
        for (int i = 0; i < STAR_COUNT; i++) {
            Star star = stars[i];
            star.x -= starSpeed;
            if (star.x < 0) {
                star.x = FRAME_WIDTH;
            }
        }
    }

    private void moveCircles() {
        for (Circle circle : circles) {
            circle.x += starSpeed;
            if (circle.x > FRAME_WIDTH) {
                circle.x = -CIRCLE_RADIUS;
                circle.y = random.nextInt(FRAME_HEIGHT);
            }
        }
    }

    private void draw(Graphics g) {
        g.drawImage(backgroundImage, 0, 0, null);

        g.setColor(circleColor);
        g.fillOval(mouseX - CIRCLE_RADIUS / 2, mouseY - CIRCLE_RADIUS / 2, CIRCLE_RADIUS, CIRCLE_RADIUS);

        g.setColor(Color.WHITE);
        for (int i = 0; i < STAR_COUNT; i++) {
            Star star = stars[i];
            g.fillRect(star.x, star.y, STAR_SIZE, STAR_SIZE);
        }

        for (Circle circle : circles) {
            g.setColor(circle.color);
            g.fillOval(circle.x, circle.y, CIRCLE_RADIUS, CIRCLE_RADIUS);
        }

        g.setColor(Color.RED);
        drawSpaceship(g, spaceship1Y, Color.GRAY);
        drawSpaceship(g, FRAME_HEIGHT / 4 - SPACESHIP_HEIGHT / 4, Color.YELLOW);
    }

    private void drawSpaceship(Graphics g, int y, Color color) {
        int x = spaceship2X;

        // Body
        g.setColor(color);
        g.fillRoundRect(x, y, SPACESHIP_WIDTH, SPACESHIP_HEIGHT, 10, 10);

        // Wings
        g.setColor(Color.BLACK);
        g.fillRect(x, y + SPACESHIP_HEIGHT / 3, SPACESHIP_WIDTH / 2, SPACESHIP_HEIGHT / 3);
        g.fillRect(x + SPACESHIP_WIDTH / 2, y + SPACESHIP_HEIGHT / 4, SPACESHIP_WIDTH / 2, SPACESHIP_HEIGHT / 2);

        // Cockpit
        g.setColor(Color.BLACK);
        int[] cockpitX = {x + SPACESHIP_WIDTH / 2, x + SPACESHIP_WIDTH / 2 - SPACESHIP_WIDTH / 10, x + SPACESHIP_WIDTH / 2 + SPACESHIP_WIDTH / 10};
        int[] cockpitY = {y + SPACESHIP_HEIGHT / 2, y + SPACESHIP_HEIGHT / 2 + SPACESHIP_HEIGHT / 10, y + SPACESHIP_HEIGHT / 2 + SPACESHIP_HEIGHT / 10};
        g.fillPolygon(cockpitX, cockpitY, 3);
    }

    private static class Star {
        public int x;
        public int y;

        public Star(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    private static class Circle {
        public int x;
        public int y;
        public Color color;

        public Circle(int x, int y, Color color) {
            this.x = x;
            this.y = y;
            this.color = color;
        }
    }

    private static Star[] stars;
    static File file;
    static AudioInputStream stream;
    static Clip music;
    public static void main(String[] args) throws Exception{
        stars = new Star[STAR_COUNT];
        for (int i = 0; i < STAR_COUNT; i++) {
            int x = (int) (Math.random() * FRAME_WIDTH);
            int y = (int) (Math.random() * FRAME_HEIGHT);
            stars[i] = new Star(x, y);
        }

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                StarryNight frame = new StarryNight();
                frame.setVisible(true);
            }
        });
        
        file = new File("music.wav");//File must be .WAV, .AU, or .AIFF
		stream = AudioSystem.getAudioInputStream(file);
		music = AudioSystem.getClip();
		music.open(stream);
		music.start(); //Start the music
		music.loop(Clip.LOOP_CONTINUOUSLY); //Loop the music
    }

    private Color getRandomColor() {
        int r = random.nextInt(256);
        int g = random.nextInt(256);
        int b = random.nextInt(256);
        return new Color(r, g, b);
    }

    private BufferedImage scaleImage(BufferedImage image, int width, int height) {
        Image scaledImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        Graphics2D graphics = bufferedImage.createGraphics();
        graphics.drawImage(scaledImage, 0, 0, null);
        graphics.dispose();

        return bufferedImage;
    }
}









